package com.example.hellogeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellogenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
