package com.LojaDeGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaDeGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
