package com.farmacia.farmaciaGeneration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmaciaGenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmaciaGenerationApplication.class, args);
	}

}
